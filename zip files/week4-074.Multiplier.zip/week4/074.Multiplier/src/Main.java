
public class Main {

    public static void main(String[] args) {
        // This is an empty main method which you can use to test your class's functionality.
    }
}
